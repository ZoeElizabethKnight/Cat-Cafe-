# A Basic Web design

This is a rough web design. You can see what it looks like here [https://sheffieldjournalism.github.io/basic-web-design/](https://sheffieldjournalism.github.io/basic-web-design/)

If you'd like to use this as a starting template for the next web building lesson, use the green Clone/Download button above to download it as a zip file. 

Remember - you will need to **excract** the zip file first before working on it!
